-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Mar 10, 2017 at 01:09 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--
CREATE DATABASE IF NOT EXISTS `library` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `library`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `id` bigint(20) unsigned NOT NULL,
  `author_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `author_name`) VALUES
(14, 'Michael Jordan'),
(15, 'Science Guy'),
(16, 'Phil Jackson'),
(17, 'Scottie Pippen'),
(18, 'Some programming guy');

-- --------------------------------------------------------

--
-- Table structure for table `authors_books`
--

DROP TABLE IF EXISTS `authors_books`;
CREATE TABLE `authors_books` (
  `id` bigint(20) unsigned NOT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `book_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authors_books`
--

INSERT INTO `authors_books` (`id`, `author_id`, `book_id`) VALUES
(15, 14, 14),
(16, 15, 15),
(17, 14, 16),
(18, 16, 14),
(19, 17, 14),
(20, 18, 17);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `synopsis` varchar(255) DEFAULT NULL,
  `genre_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `publish_date`, `synopsis`, `genre_id`) VALUES
(14, 'Basketball History', '2017-03-14', 'basketball stuff', NULL),
(15, 'The Planets', '2017-03-21', 'stuff about space', NULL),
(16, 'Basketball Playbook', '2015-10-30', 'basketball plays', NULL),
(17, 'Art of Programming', '2017-03-27', 'about programming, maybe?', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `book_copies`
--

DROP TABLE IF EXISTS `book_copies`;
CREATE TABLE `book_copies` (
  `id` bigint(20) unsigned NOT NULL,
  `book_condition` tinyint(4) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `book_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_copies`
--

INSERT INTO `book_copies` (`id`, `book_condition`, `comment`, `book_id`) VALUES
(44, 5, 'new', 14),
(45, 5, 'new', 14),
(46, 5, 'new', 14),
(47, 5, 'new', 15),
(48, 5, 'new', 15),
(49, 5, 'new', 15),
(50, 5, 'new', 15),
(51, 5, 'new', 16),
(52, 5, 'new', 16),
(53, 5, 'new', 16),
(54, 5, 'new', 16),
(55, 5, 'new', 16),
(56, 5, 'new', 16),
(57, 5, 'new', 17),
(58, 5, 'new', 17);

-- --------------------------------------------------------

--
-- Table structure for table `checkouts`
--

DROP TABLE IF EXISTS `checkouts`;
CREATE TABLE `checkouts` (
  `id` bigint(20) unsigned NOT NULL,
  `book_copy_id` bigint(20) DEFAULT NULL,
  `patron_id` bigint(20) DEFAULT NULL,
  `checkout_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `returned_date` date DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `still_out` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checkouts`
--

INSERT INTO `checkouts` (`id`, `book_copy_id`, `patron_id`, `checkout_date`, `due_date`, `returned_date`, `comment`, `still_out`) VALUES
(1, 44, 1, '2017-03-09', '2017-03-23', NULL, NULL, 1),
(2, 45, 2, '2017-03-09', '2017-03-23', NULL, NULL, 0),
(3, 47, 2, '2017-03-09', '2017-03-23', NULL, NULL, 1),
(4, 51, 1, '2017-03-09', '2017-03-23', '0000-00-00', '', 1),
(5, 45, 1, '2017-03-09', '2017-03-23', '0000-00-00', '', 1),
(6, 48, 4, '2017-03-09', '2017-03-23', '0000-00-00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `genre`
--

DROP TABLE IF EXISTS `genre`;
CREATE TABLE `genre` (
  `id` bigint(20) unsigned NOT NULL,
  `genre_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `genres`
--

DROP TABLE IF EXISTS `genres`;
CREATE TABLE `genres` (
  `id` bigint(20) unsigned NOT NULL,
  `genre_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `genres_books`
--

DROP TABLE IF EXISTS `genres_books`;
CREATE TABLE `genres_books` (
  `id` bigint(20) unsigned NOT NULL,
  `genre_id` bigint(20) DEFAULT NULL,
  `book_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patrons`
--

DROP TABLE IF EXISTS `patrons`;
CREATE TABLE `patrons` (
  `id` bigint(20) unsigned NOT NULL,
  `patron_name` varchar(255) DEFAULT NULL,
  `contact_info` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patrons`
--

INSERT INTO `patrons` (`id`, `patron_name`, `contact_info`) VALUES
(1, 'Patron 1', 'contact'),
(2, 'Patron 2', 'contact'),
(3, 'Patron 3', NULL),
(4, 'Batman', NULL),
(5, 'Spider-man', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `authors_books`
--
ALTER TABLE `authors_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `book_copies`
--
ALTER TABLE `book_copies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `checkouts`
--
ALTER TABLE `checkouts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `genres_books`
--
ALTER TABLE `genres_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `patrons`
--
ALTER TABLE `patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `authors_books`
--
ALTER TABLE `authors_books`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `book_copies`
--
ALTER TABLE `book_copies`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `checkouts`
--
ALTER TABLE `checkouts`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `genre`
--
ALTER TABLE `genre`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `genres`
--
ALTER TABLE `genres`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `genres_books`
--
ALTER TABLE `genres_books`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `patrons`
--
ALTER TABLE `patrons`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
